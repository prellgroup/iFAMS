# -*- coding: utf-8 -*-
"""
Created on Tue May 25 10:45:51 2021

@author: James
"""


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 23:33:17 2020

@author: meghandaniels
"""

import numpy as np
from scipy import stats as stats
from PyQt5 import QtWidgets, QtGui, QtCore
import os
import matplotlib.pyplot as plt

def load_file_norm(self):
    """
    Initiates the load dialog, and names two objects, x and y,
    which are arrays that hold mass (x) and area (y) values.
    A third object, "namebase" is file naming purposes in later
    save def's
    :param self:
    :return: x,y,namebase
    """
    name = QtWidgets.QFileDialog.getOpenFileName(self,'Open File')
    namestr = str(name[0])
    try:
        if namestr.endswith('.csv'):
            x, y, z = np.loadtxt(namestr,unpack=True,delimiter=',',dtype=float)
            for i in range(0, len(x)):
                x[i] = round(x[i],7)
                y[i] = round(y[i],7)
        return x, y

    except UnboundLocalError:
        print('an exception was found')
        
def sample(x,y,sample,tolerance):
    print (x)
    print (y)
    print (sample)
    print (tolerance)
    for i in range(len(x)):
        if (sample - tolerance <= x[i]) and (x[i] <= sample + tolerance):
            print (i)
            ysample = y[i]
            break
        else:
            print ('No data in range')
    return ysample
                
def standard(x,y,standard,tolerance):
    for i in range(len(x)):
        if standard - tolerance <= x[i] and x[i] <= standard + tolerance:
            ystandard = y[i]
            break
        else:
            print ('No data in range')
    return ystandard
                
def area(ysample,ystandard):
    area = ysample / ystandard
    return area

def linreg(conc,area):    
    slope, intercept, r_value, p_value, std_err = stats.linregress(conc,area)
    
    return slope, intercept, r_value, p_value, std_err

def load_file_norm2(self):
    """
    Initiates the load dialog, and names two objects, x and y,
    which are arrays that hold mass (x) and area (y) values.
    A third object, "namebase" is file naming purposes in later
    save def's
    :param self:
    :return: x,y,namebase
    """
    name = QtWidgets.QFileDialog.getOpenFileName(self,'Open File')
    namestr = str(name[0])
    try:
        if namestr.endswith('.csv'):
            x2, y2, z2 = np.loadtxt(namestr,unpack=True,delimiter=',',dtype=float)
            for i in range(0, len(x2)):
                x2[i] = round(x2[i],7)
                y2[i] = round(y2[i],7)
        return x2, y2

    except UnboundLocalError:
        print('an exception was found')
        
def sample2(x2,y2,sample2,tolerance2):
    print (x2)
    print (y2)
    print (sample2)
    print (tolerance2)
    for i in range(len(x2)):
        if (sample2 - tolerance2 <= x2[i]) and (x2[i] <= sample2 + tolerance2):
            print (i)
            ysample2 = y2[i]
            break
    return ysample2
                
def standard2(x2,y2,standard2,tolerance2):
    for i in range(len(x2)):
        if standard2 - tolerance2 <= x2[i] and x2[i] <= standard2 + tolerance2:
            ystandard2 = y2[i]
            break
    return ystandard2
                
def area2(ysample2,ystandard2):
    area2 = ysample2 / ystandard2
    return area2

def unkcalc(slope,intercept,area2):
    unkconc = (np.asarray(area2)-np.asarray(intercept)) / np.asarray(slope)
    
    print (unkconc)
    return unkconc

def load_file_norm3(self):
    """
    Initiates the load dialog, and names two objects, x and y,
    which are arrays that hold mass (x) and area (y) values.
    A third object, "namebase" is file naming purposes in later
    save def's
    :param self:
    :return: x,y,namebase
    """
    name = QtWidgets.QFileDialog.getOpenFileName(self,'Open File')
    namestr = str(name[0])
    try:
        if namestr.endswith('.csv'):
            x3, y3 = np.loadtxt(namestr,unpack=True,delimiter=',',dtype=float)
            for i in range(0, len(x3)):
                x3[i] = round(x3[i],7)
                y3[i] = round(y3[i],7)
        return x3, y3

    except UnboundLocalError:
        print('an exception was found')

""""
for noise calculation

will take range of x values and append their y values to a list
"""
def noisefile(x3,y3,minmz,maxmz):
    noiseabun = []
    for i in range(0, len(x3)):
        if (x3[i] >= minmz) and (x3[i] <= maxmz):
            ###print (i)
            noiseabun.append(y3[i])
        
    return noiseabun


