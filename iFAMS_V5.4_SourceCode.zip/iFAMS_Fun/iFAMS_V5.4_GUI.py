# -*- coding: utf-8 -*-
"""
Created on Tue May 25 10:40:48 2021
Authors: Sean P. Cleary, Andrew K. Swansiger, Meghan M. Daniels, James S. Prell
Copyright 2016-2021, University of Oregon

iFAMS Software Academic License Agreement

The iFAMS software ("Software") has been developed by the contributing researchers James S. Prell, Sean P. Cleary,
Andrew K. Swansiger, and Meghan M. Daniels ("Developers") and made available through the University of Oregon ("UO") for your internal,
non-profit research use. The Software was developed with funding support from UO. UO and the Developers allow
researchers at your Institution to run, display, copy and modify Software on the following conditions:

1. The Software remains at your Institution and is not published, distributed, or otherwise transferred or
made available to other than Institution employees and students involved in research under your supervision.

2. You agree to make results generated using Software available to other academic researchers for non-profit
research purposes. If You wish to obtain Software for any commercial purposes, including fee-based service
projects, You will need to execute a separate licensing agreement with the University of Oregon and pay a
fee. In that case please contact: techtran@uoregon.edu. 

3.  You retain in Software and any modifications to Software, the copyright, trademark, or other notices
pertaining to Software as provided by UO and Developers.

4. You provide the Developers with feedback on the use of the Software in your research, and that the
Developers and UO are permitted to use any information You provide in making changes to the Software. All bug
reports and technical questions shall be sent to the email address: jprell@uoregon.edu

5. You acknowledge that the Developers, UO and its licensees may develop modifications to Software that may be
substantially similar to your modifications of Software, and that the Developers, UO and its licensees shall
not be constrained in any way by You in Developer’s, UO’s or its licensees’ use or management of such
modifications. You acknowledge the right of the Developers and UO to prepare and publish modifications
to Software that may be substantially similar or functionally equivalent to your modifications and
improvements, and if You obtain patent protection for any modification or improvement to Software You agree
not to allege or enjoin infringement of your patent by the Developers, UO or by any of UO’s licensees
obtaining modifications or improvements to Software from the UO or the Developers.

6. You agree to acknowledge the contribution Developers and Software make to your research, and cite
appropriate references about the Software in your publications. The current citations for the Software
can be found at:

https://dx.doi.org/10.1021/acs.analchem.6b01088
https://dx.doi.org/10.1007/s13361-018-2018-7
https://dx.doi.org/10.1002/cphc.201900022

7. Any risk associated with using the Software at your institution is with You and your Institution.
Software is experimental in nature and is made available as a research courtesy "AS IS," without obligation
by UO to provide accompanying services or support.

8. UO AND THE DEVELOPERS EXPRESSLY DISCLAIM ANY AND ALL WARRANTIES REGARDING THE SOFTWARE, WHETHER EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES PERTAINING TO NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS
FOR A PARTICULAR PURPOSE.


"""


import iFAMS_Fun.MSload as load
import iFAMS_Fun.FT as FT
import iFAMS_Fun.STFT as STFT
import iFAMS_Fun.Calibration as cal
import os
import sys
import numpy as np
from PyQt5 import QtWidgets, QtGui, QtCore
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas  ###
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar  ###
from matplotlib.figure import Figure
import scipy.signal as sp
import scipy
from scipy import stats as stats
from matplotlib.widgets import RectangleSelector
from matplotlib.patches import Rectangle
import matplotlib.pyplot as plt
color=plt.cm.tab20(np.linspace(0,1,40)) #give you 40 different colors that are evenly spaced, hopefully

class hamu(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(hamu, self).__init__(parent)
        self.setWindowTitle("Harmonic Analysis")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))
        self.hamnum_tag = QtWidgets.QLabel()
        self.hamnum_tag.setText('number of harmonics')
        self.hamnum_tag.setFixedSize(300,25)
        self.hamnum = QtWidgets.QComboBox()
        self.hamnum.addItem('select number')
        self.hamnum.addItem('1')
        self.hamnum.addItem('2')
        self.hamnum.addItem('3')
        self.hamnum.addItem('4')
        self.hamnum.addItem('5')
        self.hamnum.addItem('6')
        self.hamnum.addItem('7')
        self.hamnum.addItem('8')
        self.hamnum.addItem('9')
        self.hamnum.addItem('10')
        self.hamnum.activated[str].connect(self.harm_selc)

        self.layout = QtWidgets.QGridLayout()
        self.layout.addWidget(self.hamnum_tag)
        self.layout.addWidget(self.hamnum)
        self.setLayout(self.layout)

    def harm_selc(self,text):
        self.text = int(text)
        self.newlist = []
        self.newlist2=[]
        self.layout.removeWidget(self.hamnum_tag)
        self.layout.removeWidget(self.hamnum)
        self.hamnum_tag.setParent(None)
        self.hamnum.setParent(None)
        for i in range(0,self.text):
            self.newlist.append('self.selection'+str(i))
            self.newlist2.append('self.selnum'+str(i))
        for i in range(0,len(self.newlist)):
            label = 'include harmonic'
            self.newlist[i] = QtWidgets.QLabel()
            self.newlist[i].setText(label)
            self.newlist[i].setFixedSize(300,25)
            self.newlist2[i] = QtWidgets.QTextEdit()
            self.newlist2[i].setFixedSize(100,25)
            self.newlist2[i].setTabChangesFocus(True)
            self.layout.addWidget(self.newlist[i])
            self.layout.addWidget(self.newlist2[i])
        self.button = QtWidgets.QPushButton('run harmonic analysis')
        self.button.clicked.connect(self.harmav)
        self.layout.addWidget(self.button)
    
    def harmav(self):
        ovnum =[]
        for i in range(0,len(self.newlist)):
            ovnum.append(int(str(self.newlist2[i].toPlainText())))
        MW.IFT = FT.higher_harmonic(MW.xFT,MW.yFT,MW.submass,MW.cs,MW.y,MW.po2,ovnum)
        MW.tIFT = np.absolute(MW.IFT)
        MW.xzero, MW.cszero, MW.zerofull = FT.zerocharge(MW.tIFT, MW.xint, MW.cs)

        MW.fig.clf()
        MW.ax = MW.fig.add_subplot(121)
        MW.ax2 = MW.fig.add_subplot(122)
        MW.ax.plot(MW.x, MW.y, label='Original Spectrum')
        for i in range(len(MW.tIFT)):
            label = 'charge state ' + str(int(MW.cs[i]))
            MW.ax.plot(MW.xint, MW.tIFT[i], label=label)
        MW.ax.set_title('mass spectrum')
        MW.ax.set_ylabel('relative abundance')
        MW.ax.set_xlabel('m/z')
        MW.ax.legend(loc='upper right')

        MW.ax2.plot(MW.xzero, MW.zerofull, label='full zero')
        for i in range(len(MW.cszero)):
            label = 'charge state ' + str(int(MW.cs[i]))
            MW.ax2.plot(MW.xzero, MW.cszero[i], label=label)
        MW.ax2.set_title('zero charge spectrum')
        MW.ax2.set_ylabel('relative abundance')
        MW.ax2.set_xlabel('mass (Da)')
        MW.ax2.legend(loc='upper right')
        MW.canvas.draw()

class integrate(QtWidgets.QDialog):
    """
    This builds the iFAMS parameters recalculation window
    """

    def __init__(self, parent=None):
        super(integrate, self).__init__(parent)
        self.setWindowTitle("Parameters for Integration")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))

        self.minx_tag = QtWidgets.QLabel()
        self.minx_tag.setText('minimum x')
        self.minx_tag.setFixedSize(300,25)
        self.minx_tag.setToolTip('the x value the program will start looking for\n' 
                                'peaks to integrate')
        
        self.maxx_tag = QtWidgets.QLabel()
        self.maxx_tag.setText('maximum x')
        self.maxx_tag.setFixedSize(300,25)
        self.maxx_tag.setToolTip('the x value the program will stop looking for\n' 
                                'peaks to integrate')

        self.miny_tag = QtWidgets.QLabel()
        self.miny_tag.setText('minimum y')
        self.miny_tag.setFixedSize(300,25)
        self.miny_tag.setToolTip('this y value is the smallest peak height\n' 
                                'the program will consider an integratable peak')

        self.delta_tag = QtWidgets.QLabel()
        self.delta_tag.setText('minimum distance between peaks')
        self.delta_tag.setFixedSize(300,25)
        self.delta_tag.setToolTip('this value is the minimum distance between possible\n' 
                                'peaks needed for the program to consider them\n'
                                'two different peaks, integrating them seperately')

        self.minx = QtWidgets.QTextEdit()
        self.minx.setFixedSize(100,25)
        self.minx.setTabChangesFocus(True)
        self.maxx = QtWidgets.QTextEdit()
        self.maxx.setFixedSize(100,25)
        self.maxx.setTabChangesFocus(True)
        self.miny = QtWidgets.QTextEdit()
        self.miny.setFixedSize(100,25)
        self.miny.setTabChangesFocus(True)
        self.delta = QtWidgets.QTextEdit()
        self.delta.setFixedSize(100,25)
        self.delta.setTabChangesFocus(True)

        self.button1 = QtWidgets.QPushButton('perform integration')
        self.button1.clicked.connect(self.integrate)

        layout = QtWidgets.QGridLayout()
        layout.addWidget(self.minx_tag)
        layout.addWidget(self.minx)
        layout.addWidget(self.maxx_tag)
        layout.addWidget(self.maxx)
        layout.addWidget(self.miny_tag)
        layout.addWidget(self.miny)
        layout.addWidget(self.delta_tag)
        layout.addWidget(self.delta)
        layout.addWidget(self.button1)


        self.setLayout(layout)

    def integrate(self):
        MW.minimumX = float(str(self.minx.toPlainText()))
        MW.maximumX = float(str(self.maxx.toPlainText()))
        MW.minimumY = float(str(self.miny.toPlainText()))
        MW.deltaY = int(str(self.delta.toPlainText()))
        if MW.basecor == False:
            MW.baseline = STFT.line_baseline(MW.zerofull, MW.xzero, 5)
            MW.zerofull = MW.zerofull - MW.baseline
        MW.ynorm = MW.zerofull/max(MW.zerofull)
        MW.xlist, MW.ylist, MW.xref, MW.yref, MW.sumlist = STFT.integrate(MW.ynorm,MW.zerofull,
                                                                         MW.xzero, MW.deltaY,
                                                                         MW.minimumY, MW.minimumX, MW.maximumX)
        max_value = max(MW.zerofull)
        for i in range(0,len(MW.sumlist)):
            MW.sumlist[i] = max_value*MW.sumlist[i]
        
        
        MW.xpoints = len(np.concatenate(MW.xref))

        MW.fig.clf()
        MW.ax = MW.fig.add_subplot(121)
        MW.graphinfo = ("Zero Charge Spectrum with Integrated Peaks \n total number of points in integration =" + str(MW.xpoints))
        MW.ax.set_title(MW.graphinfo)
        MW.ax2 = MW.fig.add_subplot(122)
        MW.ax.plot(MW.xzero, MW.zerofull)
        MW.ax.set_ylabel('relative abundance')
        MW.ax.set_xlabel('mass (Da)')
        MW.xcent = []
        MW.height = []
        for i in range(0, len(MW.xlist)):
            sumnum = 0
            for j in range(len(MW.xref[i])):
                sumnum += MW.xref[i][j] * MW.yref[i][j]
            MW.height.append(MW.yref[i][int(len(MW.yref[i])/2)])
            MW.xcent.append(sumnum / sum(MW.yref[i]))
            
        for i in range(0, len(MW.xref)):
            MW.ax.fill_between(MW.xref[i], MW.yref[i])

        columns = ('mass','integration','height')
        MW.ax2.axis('tight')
        MW.ax2.axis('off')
        MW.ax2.table(cellText=np.c_[np.round(MW.xcent,4),np.round(MW.sumlist,4),np.round(MW.height,4)],colLabels=columns,loc='center')
        MW.canvas.draw()
        
class iFAMS_STFT(QtWidgets.QDialog):
    """
    This builds the iFAMS parameters recalculation window
    """

    def __init__(self, parent=None):
        super(iFAMS_STFT, self).__init__(parent)
        self.setWindowTitle("Parameters for Gabor transform")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))
        self.newlist =[]
        self.newlist2=[]
        for i in range(0,len(MW.glist)):
            self.newlist.append('self.selection'+str(i))
            self.newlist2.append('self.selnum'+str(i))
        for i in range(0,len(self.newlist)):
            label = 'selection ' + str(i+1) +' charge state'
            self.newlist[i] = QtWidgets.QLabel()
            self.newlist[i].setText(label)
            self.newlist[i].setFixedSize(300,25)
            self.newlist2[i] = QtWidgets.QTextEdit()
            self.newlist2[i].setFixedSize(100,25)
            self.newlist2[i].setTabChangesFocus(True)

        self.button1 = QtWidgets.QPushButton('run iFAMS analysis')
        self.button1.clicked.connect(self.replot)

        self.cb = QtWidgets.QCheckBox('baseline correction?')


        layout = QtWidgets.QGridLayout()
        if len(self.newlist) <= 10:
            for i in range(0,len(self.newlist)):
                layout.addWidget(self.newlist[i])
                layout.addWidget(self.newlist2[i])
            layout.addWidget(self.cb)
            layout.addWidget(self.button1)

        if len(self.newlist) > 10:
            for i in range(0,10):
                layout.addWidget(self.newlist[i],2*i,0)
                layout.addWidget(self.newlist2[i],2*i+1,0)
            for i in range(10,len(self.newlist)):
                layout.addWidget(self.newlist[i],2*i-20,1)
                layout.addWidget(self.newlist2[i],2*i+1-20,1)
            layout.addWidget(self.cb,21,0)
            layout.addWidget(self.button1,22,0)
        self.setLayout(layout)

    def replot(self):
        MW.fig.clf()
        MW.canvas.draw()
        MW.ax2 = MW.fig.add_subplot(121)
        MW.ax = MW.fig.add_subplot(122)
        MW.cs = []
        for i in range(0,len(self.newlist2)):
            MW.cs.append(int(str(self.newlist2[i].toPlainText())))
        MW.ax2.plot(MW.xint,MW.yint,label='mass spectrum')
        if MW.realsel.isChecked() == False:
            MW.tIFT = np.absolute(MW.glist)
            MW.basecor = True
        if MW.realsel.isChecked() == True:
            MW.basecor = False
            MW.tIFT = np.real(MW.glist)
        for i in range(0,len(self.newlist2)):
            label = 'selection' + str(MW.cs[i])
            MW.ax2.plot(MW.xint,MW.tIFT[i],label=label)
        MW.ax2.legend(loc='upper right', title='Charge State')
        MW.ax2.set_title('mass spectrum')
        MW.ax2.set_xlabel('m/z')
        MW.ax2.set_ylabel('relative abundance')

        MW.xzero, MW.cszero, MW.zerofull = FT.zerocharge(MW.tIFT, MW.xint, MW.cs)

        if self.cb.isChecked():
            MW.basecor = True
            if MW.realsel.isChecked() == False:
                print('no baseline correction needed for the absolute value')
            if MW.realsel.isChecked() == True:
                MW.baseline = STFT.line_baseline(MW.zerofull,MW.xzero,5)
                MW.zerofull = MW.zerofull-MW.baseline

        MW.zero_norm = MW.zerofull/max(MW.zerofull)
        MW.cs_norm = MW.cszero/max(MW.zerofull)
        MW.ax.plot(MW.xzero,MW.zero_norm, label='zero charge spectrum')
        for i in range(len(MW.cszero)):
            label = 'selection' + str(MW.cs[i])
            MW.ax.plot(MW.xzero,MW.cs_norm[i],label=label)
        MW.ax.legend(loc='upper right', title='Charge State')
        MW.ax.set_title('zero charge spectrum')
        MW.ax.set_ylabel('relative abundance')
        MW.ax.set_xlabel('mass (Da)')
        MW.canvas.draw()

class STFT_parm(QtWidgets.QDialog):
    """
    This builds the iFAMS parameters recalculation window
    """

    def __init__(self, parent=None):
        super(STFT_parm, self).__init__(parent)
        self.setGeometry(50, 50, 500, 550)
        self.setWindowTitle("STFT Parameters")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))
        self.xlist = np.arange(0,5)
        self.window_tag = QtWidgets.QLabel()
        self.window_tag.setText('window type')
        self.window_tag.setFixedSize(300,25)
        self.window = QtWidgets.QComboBox()
        self.window.addItem('select window')
        self.window.addItem('gaussian')
        self.window.addItem('hann')
        self.window.addItem('blackman')
        self.window.addItem('bartlett')
        self.window.activated[str].connect(self.window_selection)
        self.window.setFixedSize(100,25)
        self.window.setToolTip('the window type used for the Gabor Transform')

        self.winnumTag = QtWidgets.QLabel()
        self.winnumTag.setText('number of FFT channels')
        self.winnum2 = QtWidgets.QTextEdit()
        self.winnum2.setFixedSize(100,25)
        self.winnum2.setText(str(MW.winnum))
        self.winnum2.setTabChangesFocus(True)
        self.winnum2.setToolTip('This value defines frequency resolution. Increasing \n'
                                'this number will increase the frequency resolution, but \n '
                                'lower the m/z resolution.  The opposite is true for \n'
                                'a lower number')

        self.maxtag = QtWidgets.QLabel()
        self.maxtag.setText('color scale relative maximum')
        self.maxnum = QtWidgets.QTextEdit()
        self.maxnum.setFixedSize(100,25)
        self.maxnum.setText(str(MW.vmax))
        self.maxnum.setTabChangesFocus(True)
        self.maxnum.setToolTip('Adjusting this value will vary the relative maximum \n'
                               'amplitude of the spectrogram.  Less abundant signals \n'
                               'will be seen if this number is smaller')

        self.fig2 = Figure()
        self.canvas2 = FigureCanvas(self.fig2)
        self.ax5 = self.fig2.add_subplot(121)
        self.ax6 = self.fig2.add_subplot(122)
        self.button2 = QtWidgets.QPushButton('replot gabor')
        self.button2.clicked.connect(self.replotgabor)


        layout = QtWidgets.QGridLayout()
        layout.addWidget(self.canvas2)
        layout.addWidget(self.window_tag)
        layout.addWidget(self.window)
        layout.addWidget(self.winnumTag)
        layout.addWidget(self.winnum2)
        layout.addWidget(self.maxtag)
        layout.addWidget(self.maxnum)
        layout.addWidget(self.button2)


        self.setLayout(layout)


    def replotgabor(self):

        try:
            wname = self.text
            MW.winnum = int(str(self.winnum2.toPlainText()))
            MW.vmax = int(str(self.maxnum.toPlainText()))
            MW.X = STFT.stft(MW.ypadd, MW.winnum, wname)
            ytemp = STFT.re_stft(MW.X, MW.winnum, MW.ypadd, MW.yint)
            MW.correction_factor = max(MW.yint)/max(ytemp)
            MW.Xtemp = MW.X*0
            MW.ax.set_title('Gabor transform')
            MW.xshort = np.linspace(max(MW.xpadd) / len(MW.X) * 2 + min(MW.xpadd), max(MW.xpadd), len(MW.X))
            MW.yshort = np.linspace(0 - (max(MW.xFT)/len(MW.X[0]))/2, max(MW.xFT) + (max(MW.xFT)/len(MW.X[0]))/2, len(MW.X[0]))
            MW.ax.imshow(scipy.absolute(MW.X.T), origin='lower', aspect='auto',
                     interpolation='nearest',extent= [MW.xshort[0],MW.xshort[-1],MW.yshort[0],MW.yshort[-1]],cmap='jet',vmax=MW.vmax)
            MW.canvas.draw()

        except ValueError:
            print('Not all parameters entered. please enter a value for all parameters')



    def window_selection(self,text):
        self.ax5.clear(),self.ax6.clear()
        self.text = text
        if self.text == 'gaussian':
            self.winDraw = sp.get_window((text,15), 100)
        else:
            self.winDraw = sp.get_window(text,100)
        self.winDrawFT = abs(np.fft.fft(self.winDraw))
        self.winDrawFT2 = []
        for i in range(0,len(self.winDrawFT)):
            self.winDrawFT2.append(self.winDrawFT[i])
        for i in range(0,50):
            self.winDrawFT2.append(self.winDrawFT2[0])
            del self.winDrawFT2[0]
        self.ax5.plot(self.winDraw)
        self.ax5.set_title('window')
        self.ax6.plot(self.winDrawFT2)
        self.ax6.set_title('window FT')
        self.canvas2.draw()

class manu(QtWidgets.QDialog):
    """
    This builds the manual input window
    """

    def __init__(MW_3, parent=None):
        super(manu, MW_3).__init__(parent)
        MW_3.setGeometry(50, 50, 300, 200)
        MW_3.setWindowTitle("Parameters for Finding Maxima")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))

        MW_3.minchar_tag = QtWidgets.QLabel()
        MW_3.minchar_tag.setText('minimum charge state')
        MW_3.minchar_tag.setFixedSize(300,25)
        MW_3.minchar = QtWidgets.QTextEdit()
        MW_3.minchar.setFixedSize(100,25)
        MW_3.minchar.setTabChangesFocus(True)

        MW_3.maxchar_tag = QtWidgets.QLabel()
        MW_3.maxchar_tag.setText('maximum charge state')
        MW_3.maxchar_tag.setFixedSize(300,25)
        MW_3.maxchar = QtWidgets.QTextEdit()
        MW_3.maxchar.setFixedSize(100,25)
        MW_3.maxchar.setTabChangesFocus(True)

        MW_3.sm_tag = QtWidgets.QLabel()
        MW_3.sm_tag.setText('subunit mass')
        MW_3.sm_tag.setFixedSize(300,25)
        MW_3.sm = QtWidgets.QTextEdit()
        MW_3.sm.setFixedSize(100,25)
        MW_3.sm.setTabChangesFocus(True)

        MW_3.button1 = QtWidgets.QPushButton('update finder')
        MW_3.button1.clicked.connect(MW_3.recalculate)

        layout = QtWidgets.QGridLayout()
        layout.addWidget(MW_3.minchar_tag)
        layout.addWidget(MW_3.minchar)
        layout.addWidget(MW_3.maxchar_tag)
        layout.addWidget(MW_3.maxchar)
        layout.addWidget(MW_3.sm_tag)
        layout.addWidget(MW_3.sm)
        layout.addWidget(MW_3.button1)
        MW_3.setLayout(layout)

    def recalculate(MW_3):
        try:
            mincharge = float(str(MW_3.minchar.toPlainText()))
            maxcharge = float(str(MW_3.maxchar.toPlainText()))
            MW.submass = float(str(MW_3.sm.toPlainText()))
            MW.cs = np.linspace(mincharge,maxcharge,int(maxcharge-mincharge+1))
            MW.xvalues,MW.yvalues = FT.rel_freq(MW.cs,MW.submass,MW.xFT,MW.yFT)

            MW.fig.clf()
            MW.ax = MW.fig.add_subplot(121)
            MW.ax2 = MW.fig.add_subplot(122)

            MW.ax.plot(MW.xint, MW.yint)
            MW.ax.set_title('mass spectrum')
            MW.ax.set_ylabel('relative abundance')
            MW.ax.set_xlabel('m/z')

            MW.ax2.plot(MW.xFT, abs(MW.yFT))
            MW.ax2.scatter(MW.xvalues,MW.yvalues,color='g')
            MW.ax2.set_title('Fourier spectrum')
            MW.ax2.set_ylabel('relative amplitude')
            MW.ax2.set_xlabel('frequency')
            MW.ax2.set_xlim(0, MW.xFT[-1] / 2)
            MW.canvas.draw()

        except ValueError:
            print('Missing a value.  Make sure each box has a value in it')

        except AttributeError:
            print('No data found for Fourier transform.  Please load in data set')


class Maxi(QtWidgets.QDialog):
    """
    This builds the iFAMS parameters recalculation window
    """

    def __init__(MW_2, parent=None):
        super(Maxi, MW_2).__init__(parent)
        MW_2.setGeometry(50, 50, 300, 200)
        MW_2.setWindowTitle("Parameters for Finding Maxima")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))


        MW_2.minFreq_tag = QtWidgets.QLabel()
        MW_2.minFreq_tag.setText('minimum frequency')
        MW_2.minFreq_tag.setFixedSize(300,25)
        MW_2.minFreq = QtWidgets.QTextEdit()
        MW_2.minFreq.setText('0.001')
        MW_2.minFreq.setFixedSize(100,25)
        MW_2.minFreq.setTabChangesFocus(True)

        MW_2.minAmp_tag = QtWidgets.QLabel()
        MW_2.minAmp_tag.setText('minimum amplitude')
        MW_2.minAmp_tag.setFixedSize(300,25)
        MW_2.minAmp = QtWidgets.QTextEdit()
        MW_2.minAmp.setText('1000')
        MW_2.minAmp.setFixedSize(100,25)
        MW_2.minAmp.setTabChangesFocus(True)

        MW_2.delta_tag = QtWidgets.QLabel()
        MW_2.delta_tag.setText('minimum change in frequency')
        MW_2.delta_tag.setFixedSize(300,25)
        MW_2.deltatext = QtWidgets.QTextEdit()
        MW_2.deltatext.setText('5')
        MW_2.deltatext.setFixedSize(100,25)
        MW_2.deltatext.setTabChangesFocus(True)

        MW_2.button1 = QtWidgets.QPushButton('update finder')
        MW_2.button1.clicked.connect(MW_2.chgnsubmass)

        layout = QtWidgets.QGridLayout()
        layout.addWidget(MW_2.minFreq_tag)
        layout.addWidget(MW_2.minFreq)
        layout.addWidget(MW_2.minAmp_tag)
        layout.addWidget(MW_2.minAmp)
        layout.addWidget(MW_2.delta_tag)
        layout.addWidget(MW_2.deltatext)
        layout.addWidget(MW_2.button1)
        MW_2.setLayout(layout)

    def chgnsubmass(MW_2):
        try:
            minFreq = float(str(MW_2.minFreq.toPlainText()))
            minAmp = float(str(MW_2.minAmp.toPlainText()))
            delta = int(str(MW_2.deltatext.toPlainText()))
            MW.xvalues, MW.yvalues = FT.peakfinder(MW.xFT, np.abs(MW.yFT), minFreq, minAmp, delta)
            MW.cs, MW.submass, stdevmass = FT.chgnsubmass(MW.xvalues, MW.xFT, np.abs(MW.yFT))

            MW.fig.clf()
            MW.ax = MW.fig.add_subplot(121)
            MW.ax2 = MW.fig.add_subplot(122)

            MW.ax.plot(MW.xint, MW.yint)
            MW.ax.set_title('mass spectrum')
            MW.ax.set_ylabel('relative abundance')
            MW.ax.set_xlabel('m/z')

            MW.ax2.plot(MW.xFT, abs(MW.yFT))
            MW.ax2.scatter(MW.xvalues, np.abs(MW.yvalues), color='g')
            MW.ax2.set_title('Fourier spectrum')
            MW.ax2.set_ylabel('relative amplitude')
            MW.ax2.set_xlabel('frequency')
            MW.ax2.set_xlim(0, MW.xFT[-1] / 2)
            text = 'the charge states are ' + str(MW.cs) +' \nand the subunit mass is ' + str(round(MW.submass,3)) \
                   + '+/-' + str(round(stdevmass,3))
            MW.ax2.text(0.5, 0.9,text, horizontalalignment='center', verticalalignment='center',
                        transform=MW.ax2.transAxes,color='g',fontsize=12)
            MW.canvas.draw()
        except TypeError:
            print()
        except ValueError:
            print('Not enough parameters entered.  Please enter a value in each box.')
            
class Calibration(QtWidgets.QDialog):
    """
    This builds the iFAMS calibration curve window and the unknown calculator
    """
    
    def __init__(self, parent=None):
        super(Calibration, self).__init__(parent)
        self.setWindowTitle("Calibration Parameters")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))

        self.data_tag = QtWidgets.QLabel()
        self.data_tag.setText('number of data points')
        self.data_tag.setFixedSize(300,25)
        self.data = QtWidgets.QComboBox()
        self.data.addItem('select number')
        self.data.addItem('1')
        self.data.addItem('2')
        self.data.addItem('3')
        self.data.addItem('4')
        self.data.addItem('5')
        self.data.addItem('6')
        self.data.addItem('7')
        self.data.addItem('8')
        self.data.addItem('9')
        self.data.addItem('10')
        self.data.activated[str].connect(self.calpoints)
 
        self.layout = QtWidgets.QGridLayout() 
        self.layout.addWidget(self.data_tag)
        self.layout.addWidget(self.data)
        self.setLayout(self.layout)
        
    def calpoints(self,text):
        """
        creates the menu for inputting standard mass, sample mass, tolerance
        and concentrations
        """
        
        self.text = int(text)
        self.newlist = []
        self.newlist2 = []
        self.newlist3 = []
        self.layout.removeWidget(self.data_tag)
        self.layout.removeWidget(self.data)
        self.data_tag.setParent(None)
        self.data.setParent(None)
        
        self.sample_tag = QtWidgets.QLabel()
        self.sample_tag.setText('sample mass')
        self.sample_tag.setFixedSize(300,25)
        
        self.standard_tag = QtWidgets.QLabel()
        self.standard_tag.setText('standard mass')
        self.standard_tag.setFixedSize(300,25)
        
        self.tolerance_tag = QtWidgets.QLabel()
        self.tolerance_tag.setText('tolerance')
        self.tolerance_tag.setFixedSize(300,25) 

        
        self.sample = QtWidgets.QTextEdit()
        self.sample.setFixedSize(100,25)
        self.sample.setTabChangesFocus(True)
        self.standard = QtWidgets.QTextEdit()
        self.standard.setFixedSize(100,25)
        self.standard.setTabChangesFocus(True)
        self.tolerance = QtWidgets.QTextEdit()
        self.tolerance.setFixedSize(100,25)
        self.tolerance.setTabChangesFocus(True)
        self.tolerance.setToolTip('How far from expected sample or standard mass \n' 
                                      'is acceptable to use for the calibration \n'
                                      'curve?')

        self.layout.addWidget(self.sample_tag)
        self.layout.addWidget(self.sample)
        self.layout.addWidget(self.standard_tag)
        self.layout.addWidget(self.standard)
        self.layout.addWidget(self.tolerance_tag)
        self.layout.addWidget(self.tolerance)
               
        for i in range(0,self.text):
            self.newlist.append('self.concdata'+str(i))
            self.newlist2.append('self.concnum'+str(i))
            self.newlist3.append('self.areanum'+str(i))
            
        for i in range(0,len(self.newlist)):
            label = 'concentration' 
            self.newlist[i] = QtWidgets.QLabel()
            self.newlist[i].setText(label)
            self.newlist[i].setFixedSize(300,25)
            self.newlist2[i] = QtWidgets.QTextEdit()
            self.newlist2[i].setFixedSize(100,25)
            self.newlist2[i].setTabChangesFocus(True)
            self.layout.addWidget(self.newlist[i])
            self.layout.addWidget(self.newlist2[i])
            
        self.button1 = QtWidgets.QPushButton('load integration files')
        self.button1.clicked.connect(self.areapoints)
        self.layout.addWidget(self.button1)
        self.button1.setToolTip('Select files in order of concentrations \n' 
                                'inputted above')
                                                         
        self.button2 = QtWidgets.QPushButton('create calibration curve')
        self.button2.clicked.connect(self.calcurve)
        self.layout.addWidget(self.button2)
        
        self.button3 = QtWidgets.QPushButton('calculate unknown concentration')
        self.button3.clicked.connect(self.unknownconc)
        self.layout.addWidget(self.button3)
        
    def areapoints(self):
        """
        calculates the area point needed to create the calibration curve
        """
        
        MW.x = []
        MW.y = []
        MW.ysample = []
        MW.ystandard = []
        MW.areapoint = []

        for i in range(0,len(self.newlist)):
            MW.x.append('self.xdata'+str(i))
            MW.y.append('self.ydata'+str(i))
            MW.ysample.append('self.ysamp'+str(i))
            MW.ystandard.append('self.ystnd'+str(i))
            MW.areapoint.append('self.areadata'+str(i))
            
        for i in range(0,len(self.newlist)):
        
            MW.x[i], MW.y[i] = cal.load_file_norm(self)
            MW.sample = float(str(self.sample.toPlainText()))
            MW.standard = float(str(self.standard.toPlainText()))
            MW.tolerance = float(str(self.tolerance.toPlainText()))
            MW.ysample[i] = cal.sample(MW.x[i],MW.y[i],MW.sample,MW.tolerance)
            MW.ystandard[i] = cal.standard(MW.x[i],MW.y[i],MW.standard,MW.tolerance)
            MW.areapoint[i] = cal.area(MW.ysample[i],MW.ystandard[i])
        
        print (MW.areapoint)
        
        return MW.areapoint[i], MW.sample, MW.standard
    
    def calcurve(self):
        """
        plots the calibration curve and stores the slope and intercept
        """
        
        MW.conc = []

        for i in range(0,len(self.newlist)):
            MW.conc.append(float(str(self.newlist2[i].toPlainText())))   
        print (MW.conc)


        MW.slope, MW.intercept, MW.r_value, MW.p_value, MW.std_err = cal.linreg(MW.conc,MW.areapoint)

        MW.calx = np.linspace(0,max(MW.conc),10,endpoint=True)
        MW.caly = MW.slope*MW.calx+MW.intercept
        
        MW.fig.clf()
        MW.ax = MW.fig.add_subplot(111)
        MW.ax.plot(MW.conc, MW.areapoint,linestyle='None',marker='.')
        MW.ax.plot(MW.calx, MW.caly)
        MW.calinfo = "Calibration Curve \n y = " + str(MW.slope) + "x + " + str(MW.intercept) + " \n R^2 = " + str((MW.r_value)**2)
        MW.ax.set_title(MW.calinfo)
        print (MW.calinfo)
        MW.ax.set_xlabel('concentration')
        MW.ax.set_ylabel('integration')

        MW.canvas.draw()
        
        return MW.slope, MW.intercept, MW.r_value, MW.p_value, MW.std_err, MW.conc, MW.calx, MW.caly

    def unknownconc(self):
        """
        creates a menu to calculate unknown concentrations
        """
        
        self.setWindowTitle("Unknown Concentration Calculator")
        self.button1.hide()
        self.button2.hide()
        self.button3.hide()
        self.layout.removeWidget(self.sample_tag)
        self.layout.removeWidget(self.standard_tag)
        self.layout.removeWidget(self.tolerance_tag)
        self.layout.removeWidget(self.sample)
        self.layout.removeWidget(self.standard)
        self.layout.removeWidget(self.tolerance)
        self.layout.removeWidget(self.button1)
        self.layout.removeWidget(self.button2)
        self.layout.removeWidget(self.button3)
        
        for i in range(0,len(self.newlist)):
            self.layout.removeWidget(self.newlist[i])
            self.layout.removeWidget(self.newlist2[i])
            
        self.sample_tag.setParent(None)
        self.sample.setParent(None)
        self.standard_tag.setParent(None)
        self.standard.setParent(None)
        self.tolerance_tag.setParent(None)
        self.tolerance.setParent(None)

        for i in range(0,len(self.newlist)):
            self.newlist[i].setParent(None)
            self.newlist2[i].setParent(None)


        self.unknum_tag = QtWidgets.QLabel()
        self.unknum_tag.setText('number of unknown data points')
        self.unknum_tag.setFixedSize(300,25)
        self.unknum = QtWidgets.QComboBox()
        self.unknum.addItem('select number')
        self.unknum.addItem('1')
        self.unknum.addItem('2')
        self.unknum.addItem('3')
        self.unknum.addItem('4')
        self.unknum.addItem('5')
        self.unknum.addItem('6')
        self.unknum.addItem('7')
        self.unknum.addItem('8')
        self.unknum.addItem('9')
        self.unknum.addItem('10')
        self.unknum.activated[str].connect(self.concpoints)
      
        self.layout.addWidget(self.unknum_tag)
        self.layout.addWidget(self.unknum)


    def concpoints(self,text2):
        self.text2 = int(text2)
        self.newlist4 = []
        self.newlist5 = []
        self.newlist6 = []
        self.layout.removeWidget(self.unknum_tag)
        self.layout.removeWidget(self.unknum)
        self.unknum_tag.setParent(None)
        self.unknum.setParent(None)

        self.tolerance2_tag = QtWidgets.QLabel()
        self.tolerance2_tag.setText('tolerance')
        self.tolerance2_tag.setFixedSize(300,25) 

        self.tolerance2 = QtWidgets.QTextEdit()
        self.tolerance2.setFixedSize(100,25)
        self.tolerance2.setTabChangesFocus(True)
        self.tolerance2.setToolTip('How far from expected sample or standard mass \n' 
                                      'is acceptable to use for the calibration \n'
                                      'curve?')

        self.layout.addWidget(self.tolerance2_tag)
        self.layout.addWidget(self.tolerance2)

        for i in range(0,self.text2):
            self.newlist4.append('self.unkdata'+str(i))
            self.newlist5.append('self.unknum'+str(i))
            self.newlist6.append('self.areanum'+str(i))
            
        for i in range(0,len(self.newlist4)):
            label = 'Unknown Concentration Label' 
            self.newlist4[i] = QtWidgets.QLabel()
            self.newlist4[i].setText(label)
            self.newlist4[i].setFixedSize(300,25)
            self.newlist5[i] = QtWidgets.QTextEdit()
            self.newlist5[i].setFixedSize(100,25)
            self.newlist5[i].setTabChangesFocus(True)
            self.layout.addWidget(self.newlist4[i])
            self.layout.addWidget(self.newlist5[i])
            
        self.button4 = QtWidgets.QPushButton('load integration files')
        self.button4.clicked.connect(self.areapoints2)
        self.layout.addWidget(self.button4)
        self.button1.setToolTip('Note order of files selected for \n' 
                                'table output')
                                                         
        self.button5 = QtWidgets.QPushButton('calculate unknown concentration')
        self.button5.clicked.connect(self.calcunk)
        self.layout.addWidget(self.button5)
        
    def areapoints2(self):
        MW.x2 = []
        MW.y2 = []
        MW.ysample2 = []
        MW.ystandard2 = []
        MW.areapoint2 = np.zeros(len(self.newlist4))

        for i in range(0,len(self.newlist4)):
            MW.x2.append('self.xdata'+str(i))
            MW.y2.append('self.ydata'+str(i))
            MW.ysample2.append('self.ysamp'+str(i))
            MW.ystandard2.append('self.ystnd'+str(i))
            
        for i in range(0,len(self.newlist4)):
        
            MW.x2[i], MW.y2[i] = cal.load_file_norm2(self)
            MW.tolerance2 = float(str(self.tolerance2.toPlainText()))
            MW.ysample2[i] = cal.sample2(MW.x2[i],MW.y2[i],MW.sample,MW.tolerance2)
            MW.ystandard2[i] = cal.standard2(MW.x2[i],MW.y2[i],MW.standard,MW.tolerance2)
            MW.areapoint2[i] = cal.area2(MW.ysample2[i],MW.ystandard2[i])
        
        print (MW.areapoint2)
        
        return MW.areapoint2[i]
    
    def calcunk(self):
        MW.unkconc = np.zeros(len(self.newlist4))
        self.unklab = []

        for i in range(0,len(self.newlist4)):
            self.unklab.append(float(str(self.newlist5[i].toPlainText())))   
        print (self.unklab)
                
        for i in range(0,len(self.newlist4)):
            MW.unkconc[i] = cal.unkcalc(MW.slope,MW.intercept,MW.areapoint2[i])
         
            print (MW.unkconc)

            
        MW.fig.clf()
        MW.ax2 = MW.fig.add_subplot(121)
        MW.ax3 = MW.fig.add_subplot(122)
        MW.ax2.plot(MW.conc, MW.areapoint,linestyle='None',marker='o')
        
        MW.ax2.plot(MW.unkconc, MW.areapoint2, linestyle = 'None', marker='s',color = 'green')
        
        MW.ax2.plot(MW.calx, MW.caly)
        MW.calinfo = "Calibration Curve \n y = " + str(MW.slope) + "x + " + str(MW.intercept) + " \n R^2 = " + str((MW.r_value)**2)
        MW.ax2.set_title(MW.calinfo)
        print (MW.calinfo)
        MW.ax2.set_xlabel('concentration')
        MW.ax2.set_ylabel('integration')
                
        columns = ('Unknown','Concentration')
        MW.ax3.axis('tight')
        MW.ax3.axis('off')
        MW.ax3.table(cellText=np.c_[np.round(self.unklab,8),np.round(MW.unkconc,4)],colLabels=columns,loc='center',cellLoc='center')

        MW.canvas.draw() 

        return MW.unkconc
    
class HarmonicFinder(QtWidgets.QDialog):
    """
    This builds the automatic harmonic finder parameter box
    """
    
    def __init__(self, parent=None):
        super(HarmonicFinder, self).__init__(parent)
        self.setWindowTitle("Harmonic Finder Parameters")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))
        
        
        self.harmnum_tag = QtWidgets.QLabel()
        self.harmnum_tag.setText('number of harmonics')
        self.harmnum_tag.setFixedSize(300,25)
        self.harmnum = QtWidgets.QComboBox()
        self.harmnum.addItem('select number')
        self.harmnum.addItem('1')
        self.harmnum.addItem('2')
        self.harmnum.addItem('3')
        self.harmnum.addItem('4')
        self.harmnum.addItem('5')
        self.harmnum.addItem('6')
        self.harmnum.addItem('7')
        self.harmnum.addItem('8')
        self.harmnum.addItem('9')
        self.harmnum.addItem('10')
        self.harmnum.activated[str].connect(self.harmboxes)
 
        self.layout = QtWidgets.QGridLayout() 
        self.layout.addWidget(self.harmnum_tag)
        self.layout.addWidget(self.harmnum)
        self.setLayout(self.layout)
        
    def harmboxes(self, text):
        self.text = int(text)
        self.newlist = []
        self.newlist2 = []
        self.layout.removeWidget(self.harmnum_tag)
        self.layout.removeWidget(self.harmnum)
        self.harmnum_tag.setParent(None)
        self.harmnum.setParent(None)
               
        for i in range(0,self.text):
            self.newlist.append('self.selec'+str(i))
            self.newlist2.append('self.selecnum'+str(i))
            
        for i in range(0,len(self.newlist)):
            label = 'include harmonics' 
            self.newlist[i] = QtWidgets.QLabel()
            self.newlist[i].setText(label)
            self.newlist[i].setFixedSize(300,25)
            self.newlist2[i] = QtWidgets.QTextEdit()
            self.newlist2[i].setFixedSize(100,25)
            self.newlist2[i].setTabChangesFocus(True)
            self.layout.addWidget(self.newlist[i])
            self.layout.addWidget(self.newlist2[i])
            
        self.button1 = QtWidgets.QPushButton('add harmonics to plot')
        self.button1.clicked.connect(self.harmadder)
        self.layout.addWidget(self.button1)
        self.button1.setToolTip('Add harmonic boxes to Gabor Spectra by clicking\n'
                                'on the Gabor Plot')
        self.button2 = QtWidgets.QPushButton('start iFAMS analysis')
        self.button2.clicked.connect(self.harmcs)

        self.layout.addWidget(self.button2)
        
    def harmadder(self):
        harmonicnum =[]
        harmonicrlist = MW.rlist.copy()
        intermrlist = MW.rlist.copy()
        
        
        for i in range(0,len(self.newlist)):
            harmonicnum.append(int(str(self.newlist2[i].toPlainText())))
        print (harmonicnum)
        
        
        for i in range(len(harmonicrlist)):
            harmstorage = []
            for k in range(len(harmonicnum)):
                rex = Rectangle((harmonicrlist[i][0], (((harmonicnum[k]-1) * ((harmonicrlist[i][2]+harmonicrlist[i][3])/2))+harmonicrlist[i][2])), (harmonicrlist[i][1] - harmonicrlist[i][0]), (harmonicrlist[i][3] - harmonicrlist[i][2]), facecolor='none', edgecolor=color[harmonicrlist[i][4]], linewidth=3)
                
                harmstorage.append([harmonicrlist[i][0], harmonicrlist[i][1], (harmonicnum[k] * harmonicrlist[i][2]), (harmonicnum[k] * harmonicrlist[i][3]), harmonicrlist[i][4]])
    
                MW.ax.add_artist(rex) 
            
            harmstorlist = []
            for m in harmstorage:
                harmstorlist += m
            intermrlist.insert((i*2)+1,harmstorlist)

        MW.rliststor = []
        MW.rliststor = sum(intermrlist, [])
        
        MW.rlist = []
        MW.rlist = [MW.rliststor[i:i + 5] for i in range(0, len(MW.rliststor), 5)]
        
    def harmcs(self):
        self.layout.removeWidget(self.button1)
        self.layout.removeWidget(self.button2)
        self.button1.setParent(None)
        self.button2.setParent(None)
        for i in range(0,len(self.newlist)):
            self.layout.removeWidget(self.newlist[i])
            self.layout.removeWidget(self.newlist2[i])
        for i in range(0,len(self.newlist)):
            self.newlist[i].setParent(None)
            self.newlist2[i].setParent(None)
        
        self.setWindowTitle("Parameters for Gabor transform")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))
        self.newlist3 =[]
        self.newlist4=[]
        for i in range(0,len(MW.glist)):
            self.newlist3.append('self.selection'+str(i))
            self.newlist4.append('self.selnum'+str(i))
        print (len(self.newlist3))
        print (len(self.newlist4))
        for i in range(0,len(self.newlist3)):
            label = 'selection ' + str(i+1) +' charge state'
            self.newlist3[i] = QtWidgets.QLabel()
            self.newlist3[i].setText(label)
            self.newlist3[i].setFixedSize(300,25)
            self.newlist4[i] = QtWidgets.QTextEdit()
            self.newlist4[i].setFixedSize(100,25)
            self.newlist4[i].setTabChangesFocus(True)

        self.button1 = QtWidgets.QPushButton('run iFAMS analysis')
        self.button1.clicked.connect(self.replot)

        if len(self.newlist) <= 10:
            for i in range(0,len(self.newlist3)):
                self.layout.addWidget(self.newlist3[i])
                self.layout.addWidget(self.newlist4[i])
            self.layout.addWidget(self.button1)

        if len(self.newlist) > 10:
            for i in range(0,10):
                self.layout.addWidget(self.newlist3[i],2*i,0)
                self.layout.addWidget(self.newlist4[i],2*i+1,0)
            for i in range(10,len(self.newlist3)):
                self.layout.addWidget(self.newlist3[i],2*i-20,1)
                self.layout.addWidget(self.newlist4[i],2*i+1-20,1)
            self.layout.addWidget(self.button1,22,0)
        
    def replot(self):
        MW.fig.clf()
        MW.canvas.draw()
        MW.ax2 = MW.fig.add_subplot(121)
        MW.ax = MW.fig.add_subplot(122)
        MW.cs = []
        for i in range(0,len(self.newlist4)):
            MW.cs.append(int(str(self.newlist4[i].toPlainText())))
            
        
        MW.rectangles = load.rec(MW.rlist,MW.cs)
        

        MW.tIFT = []

        print('starting STFT analysis')
        for j in range(len(MW.cs)):
            MW.Xtemp = MW.X*0
            for m in range(len(MW.rectangles[j])):
                for k in range(0, len(MW.X)):
                    for l in range(0, len(MW.X[0])):
                        if MW.xshort[k] >= MW.rectangles[j][m][0] and MW.xshort[k] <= MW.rectangles[j][m][1] and\
                            MW.yshort[l] >= MW.rectangles[j][m][2] and MW.yshort[l] <= MW.rectangles[j][m][3]:

                            MW.Xtemp[k][l] = MW.X[k][l]
            MW.yrecon = STFT.re_stft(MW.Xtemp, MW.winnum, MW.ypadd, MW.yint) * MW.correction_factor
            if MW.realsel.isChecked() == False:
                MW.tIFT.append(np.absolute(MW.yrecon))
            if MW.realsel.isChecked() == True:
                MW.tIFT.append(np.real(MW.yrecon))
                        
            MW.glist = MW.tIFT
            

        MW.ax2.plot(MW.xint,MW.yint,label='mass spectrum')
        if MW.realsel.isChecked() == False:
            MW.tIFT = np.absolute(MW.glist)
            MW.basecor = True
        if MW.realsel.isChecked() == True:
            MW.basecor = False
            MW.tIFT = np.real(MW.glist)
        for i in range(0,len(self.newlist4)):
            label = 'selection' + str(MW.cs[i])
            MW.ax2.plot(MW.xint,MW.tIFT[i],label=label)
        MW.ax2.legend(loc='upper right', title='Charge State')
        MW.ax2.set_title('mass spectrum')
        MW.ax2.set_xlabel('m/z')
        MW.ax2.set_ylabel('relative abundance')

        MW.xzero, MW.cszero, MW.zerofull = FT.zerocharge(MW.tIFT, MW.xint, MW.cs)

        MW.zero_norm = MW.zerofull/max(MW.zerofull)
        MW.cs_norm = MW.cszero/max(MW.zerofull)
        MW.ax.plot(MW.xzero,MW.zero_norm, label='zero charge spectrum')
        for i in range(len(MW.cszero)):
            label = 'selection' + str(MW.cs[i])
            MW.ax.plot(MW.xzero,MW.cs_norm[i],label=label)
        MW.ax.legend(loc='upper right', title='Charge State')
        MW.ax.set_title('zero charge spectrum')
        MW.ax.set_ylabel('relative abundance')
        MW.ax.set_xlabel('mass (Da)')
        MW.canvas.draw()
        
                                                         
        
class Calibration2(QtWidgets.QDialog):
    """
    This builds the iFAMS calibration curve load window and the unknown calculator. This allows you to load
    a previously created calibration curve as long as it is in .csv format
    """
    
    def __init__(self, parent=None):
        super(Calibration2, self).__init__(parent)
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))
        
        
        
        self.button1 = QtWidgets.QPushButton('load calibration curve')
        self.button1.clicked.connect(self.graphcurve)
        self.button1.setToolTip('Creates calibration curve with linear regression')
        
        self.button2 = QtWidgets.QPushButton('calculate unknown concentration')
        self.button2.clicked.connect(self.UnkList)
        self.button2.setToolTip('Load data to calculate unknown concentrations')
        
        self.button1.setFocusPolicy(QtCore.Qt.NoFocus)
        self.button2.setFocusPolicy(QtCore.Qt.NoFocus)
        
        self.layout2 = QtWidgets.QGridLayout() 
        self.layout2.addWidget(self.button1)
        self.layout2.addWidget(self.button2)
        
        self.setLayout(self.layout2)
        
        
    def graphcurve(self):
        MW.conc, MW.area = cal.load_file_norm3(self)
        
        
        self.layout = QtWidgets.QGridLayout() 
        
        MW.slope, MW.intercept, MW.r_value, MW.p_value, MW.std_err = cal.linreg(MW.conc,MW.area)

        MW.calx = np.linspace(0,max(MW.conc),10,endpoint=True)
        MW.caly = MW.slope*MW.calx+MW.intercept
        
        MW.fig.clf()
        MW.ax = MW.fig.add_subplot(111)
        MW.ax.plot(MW.calx,MW.caly)
        MW.ax.plot(MW.conc, MW.area,linestyle='None',marker='.')
        MW.calinfo = "Calibration Curve \n y = " + str(MW.slope) + "x + " + str(MW.intercept) + " \n R^2 = " + str((MW.r_value)**2)
        MW.ax.set_title(MW.calinfo)
        print (MW.calinfo)
        MW.ax.set_xlabel('concentration')
        MW.ax.set_ylabel('integration')

        MW.canvas.draw()
        
        return MW.slope, MW.intercept, MW.r_value, MW.p_value, MW.std_err

        
    def UnkList(self):
        self.setWindowTitle("Unknown Concentration Calculator")
        QtWidgets.QApplication.setStyle(QtWidgets.QStyleFactory.create("Cleanlooks"))
        
        self.button1.hide()
        self.button2.hide()
        self.unknum2_tag = QtWidgets.QLabel()
        self.unknum2_tag.setText('number of unknown data points')
        self.unknum2_tag.setFixedSize(300,25)
        self.unknum2 = QtWidgets.QComboBox()
        self.unknum2.addItem('select number')
        self.unknum2.addItem('1')
        self.unknum2.addItem('2')
        self.unknum2.addItem('3')
        self.unknum2.addItem('4')
        self.unknum2.addItem('5')
        self.unknum2.addItem('6')
        self.unknum2.addItem('7')
        self.unknum2.addItem('8')
        self.unknum2.addItem('9')
        self.unknum2.addItem('10')
        self.unknum2.activated[str].connect(self.concpoints2)
      
        self.layout2.addWidget(self.unknum2_tag)
        self.layout2.addWidget(self.unknum2)  
        
    def concpoints2(self,text):
        self.text = int(text)
        self.newlist4 = []
        self.newlist5 = []
        self.newlist6 = []
        self.layout2.removeWidget(self.unknum2_tag)
        self.layout2.removeWidget(self.unknum2)
        self.unknum2_tag.setParent(None)
        self.unknum2.setParent(None)
        
        self.sample_tag = QtWidgets.QLabel()
        self.sample_tag.setText('sample mass')
        self.sample_tag.setFixedSize(300,25)
        
        self.standard_tag = QtWidgets.QLabel()
        self.standard_tag.setText('standard mass')
        self.standard_tag.setFixedSize(300,25)
        
        self.tolerance_tag = QtWidgets.QLabel()
        self.tolerance_tag.setText('tolerance')
        self.tolerance_tag.setFixedSize(300,25) 

        
        self.sample = QtWidgets.QTextEdit()
        self.sample.setFixedSize(100,25)
        self.sample.setTabChangesFocus(True)
        self.standard = QtWidgets.QTextEdit()
        self.standard.setFixedSize(100,25)
        self.standard.setTabChangesFocus(True)
        self.tolerance = QtWidgets.QTextEdit()
        self.tolerance.setFixedSize(100,25)
        self.tolerance.setTabChangesFocus(True)
        self.tolerance.setToolTip('How far from expected sample or standard mass \n' 
                                      'is acceptable to use for the calibration \n'
                                      'curve?')

        self.layout2.addWidget(self.sample_tag)
        self.layout2.addWidget(self.sample)
        self.layout2.addWidget(self.standard_tag)
        self.layout2.addWidget(self.standard)
        self.layout2.addWidget(self.tolerance_tag)
        self.layout2.addWidget(self.tolerance)

        for i in range(0,self.text):
            self.newlist4.append('self.unkdata'+str(i))
            self.newlist5.append('self.unknum'+str(i))
            self.newlist6.append('self.areanum'+str(i))
            
        for i in range(0,len(self.newlist4)):
            label = 'Unknown Concentration Label' 
            self.newlist4[i] = QtWidgets.QLabel()
            self.newlist4[i].setText(label)
            self.newlist4[i].setFixedSize(300,25)
            self.newlist5[i] = QtWidgets.QTextEdit()
            self.newlist5[i].setFixedSize(100,25)
            self.newlist5[i].setTabChangesFocus(True)
            self.layout2.addWidget(self.newlist4[i])
            self.layout2.addWidget(self.newlist5[i])
            
        self.button4 = QtWidgets.QPushButton('load integration files')
        self.button4.clicked.connect(self.areapoints2)
        self.layout2.addWidget(self.button4)
        self.button1.setToolTip('Note order of files selected for \n' 
                                'table output')
                                                         
        self.button5 = QtWidgets.QPushButton('calculate unknown concentration')
        self.button5.clicked.connect(self.calcunk)
        self.layout2.addWidget(self.button5)
        
    def areapoints2(self):
        MW.x2 = []
        MW.y2 = []
        MW.ysample2 = []
        MW.ystandard2 = []
        MW.areapoint2 = np.zeros(len(self.newlist4))

        for i in range(0,len(self.newlist4)):
            MW.x2.append('self.xdata'+str(i))
            MW.y2.append('self.ydata'+str(i))
            MW.ysample2.append('self.ysamp'+str(i))
            MW.ystandard2.append('self.ystnd'+str(i))
            
        for i in range(0,len(self.newlist4)):
        
            MW.x2[i], MW.y2[i] = cal.load_file_norm2(self)
            MW.tolerance = float(str(self.tolerance.toPlainText()))
            MW.sample = float(str(self.sample.toPlainText()))
            MW.standard = float(str(self.standard.toPlainText()))
            MW.ysample2[i] = cal.sample2(MW.x2[i],MW.y2[i],MW.sample,MW.tolerance)
            MW.ystandard2[i] = cal.standard2(MW.x2[i],MW.y2[i],MW.standard,MW.tolerance)
            MW.areapoint2[i] = cal.area2(MW.ysample2[i],MW.ystandard2[i])
        
        print (MW.areapoint2)
        
        return MW.areapoint2[i]
    
    def calcunk(self):
        MW.unkconc = np.zeros(len(self.newlist4))
        self.unklab = []

        for i in range(0,len(self.newlist4)):
            self.unklab.append(float(str(self.newlist5[i].toPlainText())))   
        print (self.unklab)
                
        for i in range(0,len(self.newlist4)):
            MW.unkconc[i] = cal.unkcalc(MW.slope,MW.intercept,MW.areapoint2[i])
         
            print (MW.unkconc)

            
        MW.fig.clf()
        MW.ax2 = MW.fig.add_subplot(121)
        MW.ax3 = MW.fig.add_subplot(122)
        MW.ax2.plot(MW.conc, MW.area,linestyle='None',marker='o')
        
        MW.ax2.plot(MW.unkconc, MW.areapoint2, linestyle = 'None', marker='s',color = 'green')
        
        MW.ax2.plot(MW.calx, MW.caly)
        MW.calinfo = "Calibration Curve \n y = " + str(MW.slope) + "x + " + str(MW.intercept) + " \n R^2 = " + str((MW.r_value)**2)
        MW.ax2.set_title(MW.calinfo)
        print (MW.calinfo)
        MW.ax2.set_xlabel('concentration')
        MW.ax2.set_ylabel('integration')
        columns = ('Unknown','Concentration')
        MW.ax3.axis('tight')
        MW.ax3.axis('off')
        MW.ax3.table(cellText=np.c_[np.round(self.unklab,8),np.round(MW.unkconc,4)],colLabels=columns,loc='center',cellLoc='center')

        MW.canvas.draw() 

        return MW.unkconc
  
class MW(QtWidgets.QMainWindow):
    """
    Main window
    """
    def __init__(self, parent=None):
        """
        This builds the main window
        it has connects to package that
        runs the script on the backend
        :param parent:
        """
        QtWidgets.QMainWindow.__init__(self, parent)
        self.create_main_frame()
        self.setWindowTitle("iFAMS v. 5.4")
        self.setWindowIcon(QtGui.QIcon('icon.png'))

        ##### file menu #####
        self.file_menu = QtWidgets.QMenu('File', self)
        self.file_menu.addAction('load ordinary FT',self.FT_load)
        self.file_menu.addAction('load STFT',self.STFT_load)
        self.file_menu.addAction('load deconvolved spectra',self.deconv_load)
        self.file_menu.addSeparator()
        self.file_menu.addAction('batch data files',self.batch)
        self.file_menu.addAction('batch deconvolved spectra', self.deconbatch)
        self.file_menu.addSeparator()
        self.file_menu.addAction('export data',self.save_FT)
        self.file_menu.addAction('export filtered spectra',self.save_filtered)
        self.menuBar().addMenu(self.file_menu)
        ##### file menu #####

        ##### Fourier analysis tools #####
        self.fourier_menu = QtWidgets.QMenu('Fourier Analysis Tools',self)
        self.fourier_menu.addAction('plot absolute data',self.plotAbs)
        self.fourier_menu.addAction('plot real data',self.plotReal)
        self.fourier_menu.addSeparator()
        self.fourier_menu.addAction('iFAMS maxima peak finder',self.maxima_finder)
        self.fourier_menu.addAction('manually enter charge states and submass',self.man_input)
        self.fourier_menu.addSeparator()
        self.fourier_menu.addAction('run iFAMS analysis',self.run_ifams)
        self.fourier_menu.addAction('run higher harmonic analysis',self.harmonic)
        self.menuBar().addMenu(self.fourier_menu)
        ##### Fourier analysis tools #####

        ##### Gabor analysis tools #####
        self.Gabor_menu = QtWidgets.QMenu('STFT Analysis Tools',self)
        self.Gabor_menu.addAction('change STFT parameters',self.STFT_parm_window)
        MW.realsel = QtWidgets.QAction('plot real data?', self, checkable=True)
        MW.realsel.setChecked(False)
        #MW.realsel.triggered.connect(self.turnonplotreal)
        self.Gabor_menu.addAction(MW.realsel)
        self.Gabor_menu.addSeparator()
        self.Gabor_menu.addAction('add Gabor selection', self.add_gabor,
                                  QtCore.Qt.CTRL + QtCore.Qt.Key_E)
        self.Gabor_menu.addAction('save Gabor selections', self.save_gabor_sel,
                                  QtCore.Qt.CTRL + QtCore.Qt.Key_S)
        self.Gabor_menu.addAction('delete previous Gabor selection', self.del_gabor,
                                  QtCore.Qt.CTRL + QtCore.Qt.Key_Delete)
        self.Gabor_menu.addAction('harmonic peak finder', self.harm_finder)
        self.Gabor_menu.addSeparator()
        self.Gabor_menu.addAction('run iFAMS analysis',self.STFT_iFAMS)
        self.Gabor_menu.addAction('perform quantitative peak integration',self.inte)
        self.Gabor_menu.addSeparator()
        self.Gabor_menu.addAction('show only spectrogram',self.show_gabor_only)
        self.menuBar().addMenu(self.Gabor_menu)
        ##### Gabor analysis tools #####
        
        ##### calibration menu #####
        self.calibration_menu = QtWidgets.QMenu('Calibration Curve Tools')
        self.calibration_menu.addAction('create new curve',self.cali)
        self.calibration_menu.addAction('load existing curve',self.cali2)
        self.calibration_menu.addSeparator()
        self.calibration_menu.addAction('save calibration curve',self.save_cali)
        self.menuBar().addMenu(self.calibration_menu)
        ##### calibration menu #####
        
    def create_main_frame(self):
        """
        makes the central plot
        :return: None
        """
        self.main_frame = QtWidgets.QWidget()

        MW.fig = Figure()

        MW.canvas = FigureCanvas(MW.fig)
        MW.canvas.setParent(self.main_frame)

        self.mpl_toolbar = NavigationToolbar(MW.canvas, self.main_frame)

        vbox = QtWidgets.QVBoxLayout()
        vbox.addWidget(MW.canvas)
        vbox.addWidget(self.mpl_toolbar)


        self.main_frame.setLayout(vbox)
        self.setCentralWidget(self.main_frame)
   
    def deconv_load(self):
        try:
            MW.xzero, MW.zerofull,MW.namebase = load.load_file_norm(self)
            MW.basecor = True
            
            MW.fig.clf()
            MW.ax = MW.fig.add_subplot(111)
            MW.ax.plot(MW.xzero, MW.zerofull)
            MW.ax.set_xlabel('mass (Da)')
            MW.ax.set_ylabel('relative abundance')
            
            MW.canvas.draw()
            
        except TypeError:
            MW.ref_num = 0
            print('Either no data loaded or wrong data type.  Try .csv or .txt for wrong data type')
            
    def FT_load(self):
        try:
            MW.x, MW.y,MW.namebase = load.load_file_norm(self)
            MW.xint,MW.yint,MW.ypadd,MW.po2,MW.xpadd = load.datapro(MW.x,MW.y)
            MW.xFT,MW.yFT = FT.Fourier(MW.x,MW.ypadd,MW.po2)

            MW.fig.clf()
            MW.ax = MW.fig.add_subplot(121)#put in upper left hand corner
            MW.ax2 = MW.fig.add_subplot(122)

            MW.ax.plot(MW.xint,MW.yint)
            MW.ax.set_title('mass spectrum')
            MW.ax.set_ylabel('relative abundance')
            MW.ax.set_xlabel('m/z')

            MW.ax2.plot(MW.xFT,abs(MW.yFT))
            MW.ax2.set_title('Fourier spectrum')
            MW.ax2.set_ylabel('relative amplitude')
            MW.ax2.set_xlabel('frequency')
            MW.ax2.set_xlim(0, MW.xFT[-1] / 2)
            MW.canvas.draw() #shows the graphs

        except TypeError:
            MW.ref_num = 0
            print('Either no data loaded or wrong data type.  Try .csv or .txt for wrong data type')

    def plotAbs(self):
        """
        plots that absolute value of the Fourier data
        :return:
        """
        try:
            MW.tIFT = np.abs(MW.IFT)
            MW.xzero,MW.cszero,MW.zerofull = FT.zerocharge(MW.tIFT,MW.xint,MW.cs)
            MW.fig.clf()
            MW.ax = MW.fig.add_subplot(121)
            MW.ax2 = MW.fig.add_subplot(122)
            MW.ax.plot(MW.x, MW.y,label = 'Original Spectrum')
            for i in range(len(MW.tIFT)):
                label = 'charge state ' + str(int(MW.cs[i]))
                MW.ax.plot(MW.xint,MW.tIFT[i],label = label)
            MW.ax.set_title('mass spectrum')
            MW.ax.set_ylabel('relative abundance')
            MW.ax.set_xlabel('m/z')
            MW.ax.legend(loc='upper right')

            MW.ax2.plot(MW.xzero, MW.zerofull,label = 'full zero')
            for i in range(len(MW.cszero)):
                label = 'charge state ' + str(int(MW.cs[i]))
                MW.ax2.plot(MW.xzero,MW.cszero[i],label = label)
            MW.ax2.set_title('zero charge spectrum')
            MW.ax2.set_ylabel('relative abundance')
            MW.ax2.set_xlabel('mass (Da)')
            MW.ax2.legend(loc = 'upper right')
            MW.canvas.draw()

        except AttributeError:
            print('Please run this command after iFAMS analysis')

    def plotReal(self):
        """
        plots the real value of the Fourier data
        :return:
        """
        try:
            MW.tIFT = np.real(MW.IFT)
            MW.xzero,MW.cszero,MW.zerofull = FT.zerocharge(MW.tIFT,MW.xint,MW.cs)
            MW.fig.clf()
            MW.ax = MW.fig.add_subplot(121)
            MW.ax2 = MW.fig.add_subplot(122)
            MW.ax.plot(MW.x, MW.y,label = 'original spectrum')
            for i in range(len(MW.tIFT)):
                label = 'charge state ' + str(int(MW.cs[i]))
                MW.ax.plot(MW.xint,MW.tIFT[i],label = label)
            MW.ax.set_title('mass spectrum')
            MW.ax.set_ylabel('relative abundance')
            MW.ax.set_xlabel('m/z')
            MW.ax.legend(loc='upper right')

            MW.ax2.plot(MW.xzero, MW.zerofull,label='full zero')
            for i in range(len(MW.cszero)):
                label = 'charge state ' + str(int(MW.cs[i]))
                MW.ax2.plot(MW.xzero,MW.cszero[i],label = label)
            MW.ax2.set_title('zero charge spectrum')
            MW.ax2.set_ylabel('relative abundance')
            MW.ax2.set_xlabel('mass (Da)')
            MW.ax2.legend(loc='upper right')
            MW.canvas.draw()

        except AttributeError:
            print('Please run this command after iFAMS analysis')

    def run_ifams(self):
        """
        runs standard iFAMS analysis
        """

        try:
            MW.IFT = FT.inverseFT(MW.xFT, MW.yFT, MW.submass, MW.cs, MW.y, MW.po2)
            MW.tIFT = np.abs(MW.IFT)
            MW.xzero,MW.cszero,MW.zerofull = FT.zerocharge(MW.tIFT,MW.xint,MW.cs)
            MW.fig.clf()
            MW.ax = MW.fig.add_subplot(121)
            MW.ax2 = MW.fig.add_subplot(122)
            MW.ax.plot(MW.x, MW.y,label = 'Original Spectrum')
            for i in range(len(MW.tIFT)):
                label = 'charge state ' + str(int(MW.cs[i]))
                MW.ax.plot(MW.xint,MW.tIFT[i],label=label)
            MW.ax.set_title('mass spectrum')
            MW.ax.set_ylabel('relative abundance')
            MW.ax.set_xlabel('m/z')
            MW.ax.legend(loc = 'upper right')

            MW.ax2.plot(MW.xzero, MW.zerofull,label = 'full zero')
            for i in range(len(MW.cszero)):
                label = 'charge state ' + str(int(MW.cs[i]))
                MW.ax2.plot(MW.xzero,MW.cszero[i],label = label)
            MW.ax2.set_title('zero charge spectrum')
            MW.ax2.set_ylabel('relative abundance')
            MW.ax2.set_xlabel('mass (Da)')
            MW.ax2.legend(loc = 'upper right')
            MW.canvas.draw()

        except AttributeError:

            print('No charge states or subunit mass found')
            print('Please either calculate charge states and subunit mass or manually enter them')

    def STFT_load(self):
        try:
            MW.fig.clf()
            MW.x, MW.y, MW.namebase = load.load_file_norm(self)
            MW.xint,MW.yint,MW.ypadd,MW.po2,MW.xpadd = load.datapro(MW.x,MW.y)
            MW.xFT,MW.yFT = FT.Fourier(MW.x,MW.ypadd,MW.po2)
            MW.winnum = int(0.04 * len(MW.yint))
            MW.stdev = int(0.1 * MW.winnum)
            MW.X = STFT.stft(MW.ypadd, MW.winnum, 'gaussian')
            ytemp = STFT.re_stft(MW.X, MW.winnum, MW.ypadd, MW.yint)
            MW.correction_factor = max(MW.yint)/max(ytemp)
            MW.Xtemp = MW.X*0
            MW.Xflat = abs(MW.X.flatten("C")) / 100
            MW.vmax = int(max(MW.Xflat))
            MW.xshort = np.linspace(max(MW.xpadd) / len(MW.X) * 2 + min(MW.xpadd), max(MW.xpadd), len(MW.X))
            MW.yshort = np.linspace(0 - (max(MW.xFT) / len(MW.X[0])) / 2, max(MW.xFT) + (max(MW.xFT) / len(MW.X[0])) / 2,
                                    len(MW.X[0]))

            MW.ax = MW.fig.add_subplot(221)
            MW.ax2 = MW.fig.add_subplot(222, sharey=MW.ax)
            MW.ax3 = MW.fig.add_subplot(223, sharex=MW.ax)
            MW.ax4 = MW.fig.add_subplot(224)

            MW.ax.imshow(abs(MW.X.T), origin='lower', aspect='auto',
                         interpolation='nearest', extent=(MW.xshort[0],MW.xshort[-1],MW.yshort[0],MW.yshort[-1]), cmap='jet',vmax=MW.vmax)
            MW.ax.set_title('Gabor spectrogram')
            MW.ax.set_xlabel('m/z')
            MW.ax.set_ylabel('frequency')
            MW.ax.set_xlim(MW.xint[0], MW.xint[-1])
            MW.ax.set_ylim(MW.xFT[0],MW.xFT[-1])

            MW.ax2.plot(abs(MW.yFT), MW.xFT)
            MW.ax2.set_title('Fourier spectrum')
            MW.ax2.set_xlabel('amplitude')
            MW.ax2.set_ylabel('frequency')

            MW.ax3.plot(MW.x, MW.y)
            MW.ax3.set_title('mass spectrum')
            MW.ax3.set_xlabel('m/z')
            MW.ax3.set_ylabel('abundance')

            MW.ax4.plot(MW.x, MW.y, color='darkgrey')
            MW.ax4.set_title('reconstructed spectrum')
            MW.ax4.set_xlabel('m/z')
            MW.ax4.set_ylabel('abundance')

            MW.toggle_selector.RS = RectangleSelector(MW.ax, self.onselect, drawtype='box', interactive=True)
            MW.glist = []
            MW.rlist = []
            MW.canvas.draw()

        except TypeError:
            print('Either no data loaded or wrong data type.  Try .csv or .txt for wrong data type')


    def onselect(self, eclick, erelease):
        MW.toggle_selector.RS.x1, MW.toggle_selector.RS.y1 = eclick.xdata, eclick.ydata
        MW.toggle_selector.RS.x2, MW.toggle_selector.RS.y2 = erelease.xdata, erelease.ydata
        if MW.toggle_selector.RS.x1 < MW.toggle_selector.RS.x2:
            MW.x1 = MW.toggle_selector.RS.x1
            MW.x2 = MW.toggle_selector.RS.x2
        if MW.toggle_selector.RS.y1 < MW.toggle_selector.RS.y2:
            MW.y1 = MW.toggle_selector.RS.y1
            MW.y2 = MW.toggle_selector.RS.y2
        if MW.toggle_selector.RS.x2 < MW.toggle_selector.RS.x1:
            MW.x2 = MW.toggle_selector.RS.x1
            MW.x1 = MW.toggle_selector.RS.x2
        if MW.toggle_selector.RS.y2 < MW.toggle_selector.RS.y1:
            MW.y2 = MW.toggle_selector.RS.y1
            MW.y1 = MW.toggle_selector.RS.y2

    def toggle_selector(event):
        if event.key == 'e':
            print('it works')

    def add_gabor(self):

        try:
            rex = Rectangle((MW.x1, MW.y1), (MW.x2 - MW.x1), (MW.y2 - MW.y1),
                            facecolor='none', edgecolor='r', linewidth=1)
            MW.rlist.append(
                [MW.x1, MW.x2, MW.y1, MW.y2, len(MW.glist)])
            MW.ax.add_artist(rex) 

            MW.ax4.clear()
            for j in range(0, len(MW.X)):
                for k in range(0, len(MW.X[0])):
                    if MW.xshort[j] >= MW.x1 and MW.xshort[j] <= MW.x2 and MW.yshort[k] >= MW.y1 and MW.yshort[k] <= MW.y2:
                        MW.Xtemp[j][k] = MW.X[j][k]
            MW.yrecon = STFT.re_stft(MW.Xtemp,MW.winnum,MW.ypadd,MW.yint)*MW.correction_factor
 

            MW.ax4.plot(MW.x, MW.y, color='darkgrey')
            if len(MW.glist) == 0:
                if MW.realsel.isChecked() == False:
                    MW.ax4.plot(MW.xint,abs(MW.yrecon),color = color[len(MW.glist)])
                if MW.realsel.isChecked() == True:
                    MW.ax4.plot(MW.xint,np.real(MW.yrecon),color = color[len(MW.glist)])
            if len(MW.glist) > 0:
                if MW.realsel.isChecked() == False:
                    for i in range(len(MW.glist)):
                        MW.ax4.plot(MW.xint,abs(MW.glist[i]),color = color[i])
                    MW.ax4.plot(MW.xint, abs(MW.yrecon), color=color[len(MW.glist)])
                if MW.realsel.isChecked() == True:
                    for i in range(len(MW.glist)):
                        MW.ax4.plot(MW.xint,np.real(MW.glist[i]),color = color[i])
                    MW.ax4.plot(MW.xint, np.real(MW.yrecon), color=color[len(MW.glist)])
            
            
            MW.ax4.set_title('reconstructed spectrum')
            MW.ax4.set_xlabel('m/z')
            MW.ax4.set_ylabel('abundance')
            MW.canvas.draw()
        except AttributeError:
            print('No rectangle on screen.  Please draw rectangle first')
            
    def save_gabor_sel(self):
        
        try:
            MW.glist.append(MW.yrecon)
            
            for i in range(len(MW.rlist)):
                rex = Rectangle((MW.rlist[i][0], MW.rlist[i][2]), (MW.rlist[i][1] - MW.rlist[i][0]), (MW.rlist[i][3] -
                                                                                                      MW.rlist[i][2]),
                                facecolor='none', edgecolor=color[MW.rlist[i][4]], linewidth=3)

                MW.ax.add_artist(rex)
            MW.Xtemp = MW.X*0
            MW.canvas.draw()
            
        except AttributeError:
            print('No rectangle on screen.  Please draw rectangle first')

    def del_gabor(self):
        try:
            len1 = MW.rlist[-1][4]
            len2 = len(MW.glist)-1
            if len1 == len2:
                MW.glist.pop()
                rlisttemp = []
                for i in range(len(MW.rlist)):
                    if MW.rlist[i][4] <= (len(MW.glist) - 1):
                        rlisttemp.append(MW.rlist[i])
                MW.rlist = rlisttemp
            if len1 > len2:
                rlisttemp = []
                for i in range(len(MW.rlist)):
                    if MW.rlist[i][4] <= (len(MW.glist)-1):
                        rlisttemp.append(MW.rlist[i])
                MW.rlist = rlisttemp
            MW.ax4.clear()
            MW.ax.clear()
            MW.ax.imshow(abs(MW.X.T), origin='lower', aspect='auto',
                         interpolation='nearest', extent=(MW.xshort[0], MW.xshort[-1], MW.yshort[0], MW.yshort[-1]),
                         cmap='jet', vmax=MW.vmax)
            MW.ax.set_title('Gabor spectrogram')
            MW.ax.set_xlabel('m/z')
            MW.ax.set_ylabel('frequency')
            MW.ax.set_xlim(MW.xint[0], MW.xint[-1])
            MW.ax.set_ylim(MW.xFT[0], MW.xFT[-1])
            MW.toggle_selector.RS = RectangleSelector(MW.ax, self.onselect, drawtype='box', interactive=True)
            for i in range(len(MW.rlist)):
                rex = Rectangle((MW.rlist[i][0], MW.rlist[i][2]), (MW.rlist[i][1] - MW.rlist[i][0]), (MW.rlist[i][3] -
                                                                                                      MW.rlist[i][2]),
                                facecolor='none', edgecolor=color[MW.rlist[i][4]], linewidth=3)
                MW.ax.add_artist(rex)
            MW.ax4.plot(MW.x, MW.y, color='darkgrey')
            if MW.realsel.isChecked() == False:
                for i in range(len(MW.glist)):
                    MW.ax4.plot(MW.xint, abs(MW.glist[i]), color=color[i])
            if MW.realsel.isChecked() == True:
                for i in range(len(MW.glist)):
                    MW.ax4.plot(MW.xint, np.real(MW.glist[i]), color=color[i])
            MW.ax4.set_title('reconstructed spectrum')
            MW.ax4.set_xlabel('m/z')
            MW.ax4.set_ylabel('abundance')
            MW.canvas.draw()

        except AttributeError:
            print('no data loaded')

        except IndexError:
            print('no more rectangles to delete')
        
    def show_gabor_only(self):
        MW.fig.clf()
        MW.ax = MW.fig.add_subplot(111)
        MW.ax.imshow(abs(MW.X.T), origin='lower', aspect='auto',
                     interpolation='nearest', extent=(MW.xshort[0], MW.xshort[-1], MW.yshort[0], MW.yshort[-1]),
                     cmap='jet', vmax=MW.vmax)
        MW.ax.set_title('Gabor spectrogram')
        MW.ax.set_xlabel('m/z')
        MW.ax.set_ylabel('frequency')
        MW.ax.set_xlim(MW.xint[0], MW.xint[-1])
        MW.ax.set_ylim(MW.xFT[0], MW.xFT[-1])
        MW.canvas.draw()

    def save_FT(self):
        try:
        
            MW.filteredspecy = [0]*len(MW.xint)
            MW.filteredy = np.real(MW.glist)
        
        except AttributeError:
            print('  ')
            
        try:
            print('saving files')
            value1 = os.path.exists(MW.namebase)
            if value1 == True:
                for file in os.scandir(MW.namebase):
                    if file.name.endswith(".csv"):
                        os.unlink(file.path)
                os.rmdir(MW.namebase)
            os.mkdir(MW.namebase)
            label = os.path.basename(MW.namebase) + ".csv"
            temp_path = os.path.join(MW.namebase, label)
            np.savetxt(temp_path, np.c_[np.round(MW.xFT, 4), np.round(abs(MW.yFT), 4)], delimiter=',')
            print('saved FT data')

        except AttributeError:
            print('no data to save')

        try:
            label = os.path.basename(MW.namebase) + "peaklist.csv"
            temp_path = os.path.join(MW.namebase, label)
            np.savetxt(temp_path, np.c_[np.round(MW.xcent, 4), np.round(MW.sumlist, 4), np.round(MW.height, 4)], delimiter=',')
            print('saved peak list')
        except AttributeError:
            print(' ')
        try:
            for i in range(len(MW.cs)):
                label = os.path.basename(MW.namebase) + "ifft" + str(int(MW.cs[i])) + ".csv"
                temp_path = os.path.join(MW.namebase, label)
                np.savetxt(temp_path, np.c_[np.round(MW.xint, 4), np.round(MW.tIFT[i], 4)], delimiter=',')
                label2 = os.path.basename(MW.namebase) + 'zerocharge' + str(int(MW.cs[i])) + '.csv'
                temp_path2 = os.path.join(MW.namebase, label2)
                np.savetxt(temp_path2, np.c_[np.round(MW.xzero, 4), np.round(MW.cszero[i], 4)], delimiter=',')
            label3 = os.path.basename(MW.namebase) + 'zerofullreal.csv'
            temp_path3 = os.path.join(MW.namebase, label3)
            np.savetxt(temp_path3, np.c_[np.round(MW.xzero, 4), np.round(MW.zerofull, 4)], delimiter=',')
            print('saved reconstructions and zero charge data')
            print('finished')

        except AttributeError:
            print('no charge state reconstructions to save')
            print('finished')
          
    def save_cali(self):
        try:
            calcurvelabel = os.path.basename(MW.namebase) + 'calcurve.csv'
            temp_path_calcurve = os.path.join(MW.namebase, calcurvelabel)
            np.savetxt(temp_path_calcurve, np.c_[np.round(MW.conc, 4), np.round(MW.areapoint, 7)], delimiter=',')
            print('saved calibration curve data')
        except AttributeError:
            print(' ')
            
    def save_filtered(self):
        MW.filteredspecy = [0]*len(MW.xint)
        MW.filteredy = np.real(MW.glist)
        
        try:
            print('saving filtered spectra')
            value1 = os.path.exists(MW.namebase)
            if value1 == True:
                for file in os.scandir(MW.namebase):
                    if file.name.endswith(".csv"):
                        os.unlink(file.path)
                os.rmdir(MW.namebase)
            os.mkdir(MW.namebase)
            label = os.path.basename(MW.namebase) + '_filteredspectra.csv'
            for i in range (0,len(MW.filteredy)):
                for j in range (len(MW.filteredy[i])):   
                    if MW.realsel.isChecked() == False:
                        MW.filteredspecy = MW.filteredspecy + abs(MW.filteredy[i])
                    if MW.realsel.isChecked() == True:
                        MW.filteredspecy = MW.filteredspecy + np.real(MW.filteredy[i])
            temp_path = os.path.join(MW.namebase, label)
            np.savetxt(temp_path, np.c_[np.round(MW.xint, 7), MW.filteredspecy], delimiter=',')
            print('saved filtered spectra')
        except AttributeError:
            print('  ')
            
    def deconbatch(self):
        self.save_FT()
        
        try:
            MW.xzero, MW.zerofull,MW.namebase = load.load_file_norm(self)
            MW.basecor = True
        
        except TypeError:
            MW.ref_num = 0
            print('Either no data loaded or wrong data type.  Try .csv or .txt for wrong data type')
            
        try:
                print ('starting integration')
                MW.ynorm = MW.zerofull/max(MW.zerofull)
                MW.xlist, MW.ylist, MW.xref, MW.yref, MW.sumlist = STFT.integrate(MW.ynorm, MW.zerofull,
                                                                                  MW.xzero, MW.deltaY,
                                                                                  MW.minimumY, MW.minimumX, MW.maximumX)
                max_value = max(MW.zerofull)
                for i in range(0, len(MW.sumlist)):
                    MW.sumlist[i] = max_value * MW.sumlist[i]
                MW.xcent = []
                MW.height = []
                for i in range(0, len(MW.xlist)):
                    sumnum = 0
                    for j in range(len(MW.xref[i])):
                        sumnum += MW.xref[i][j] * MW.yref[i][j]
                    MW.height.append(MW.yref[i][int(len(MW.yref[i])/2)])
                    MW.xcent.append(sumnum / sum(MW.yref[i]))
                for i in range(0, len(MW.xref)):
                    MW.ax.fill_between(MW.xref[i], MW.yref[i])
                    

        except AttributeError:
            print(' ')
            
        self.save_FT()   
        

    def batch(self):

        name = QtWidgets.QFileDialog.getOpenFileNames(self, 'Open File')
        self.save_FT()
        
        MW.rectangles = load.rec(MW.rlist,MW.cs)

        for i in range(0, len(name[0])):
            print('starting FT analysis for ' + str(name[0][i]))
            MW.tIFT = []
            MW.x, MW.y, MW.namebase,MW.namestr = load.batch_load(name[0][i])
            MW.xint,MW.yint,MW.ypadd,MW.po2,MW.xpadd = load.datapro(MW.x,MW.y)
            MW.xFT, MW.yFT = FT.Fourier(MW.x, MW.ypadd, MW.po2)

            try:
                MW.X = STFT.stft(MW.ypadd, MW.winnum, 'gaussian')
                MW.xshort = np.linspace(max(MW.xpadd) / len(MW.X) * 2 + min(MW.xpadd), max(MW.xpadd), len(MW.X))
                MW.yshort = np.linspace(0 - (max(MW.xFT) / len(MW.X[0])) / 2, max(MW.xFT) + (max(MW.xFT) / len(MW.X[0])) / 2,
                                        len(MW.X[0]))
                print('starting STFT analysis')
                for j in range(len(MW.cs)):
                    MW.Xtemp = MW.X*0
                    for m in range(len(MW.rectangles[j])):
                        for k in range(0, len(MW.X)):
                            for l in range(0, len(MW.X[0])):
                                if MW.xshort[k] >= MW.rectangles[j][m][0] and MW.xshort[k] <= MW.rectangles[j][m][1] and\
                                        MW.yshort[l] >= MW.rectangles[j][m][2] and MW.yshort[l] <= MW.rectangles[j][m][3]:

                                    MW.Xtemp[k][l] = MW.X[k][l]
                    MW.yrecon = STFT.re_stft(MW.Xtemp, MW.winnum, MW.ypadd, MW.yint) * MW.correction_factor
                    if MW.realsel.isChecked() == False:
                        MW.tIFT.append(np.absolute(MW.yrecon))
                    if MW.realsel.isChecked() == True:
                        MW.tIFT.append(np.real(MW.yrecon))
                        
                MW.glist = MW.tIFT
                
                print('starting zero charge analysis')
                MW.xzero, MW.cszero, MW.zerofull = FT.zerocharge(MW.tIFT, MW.xint, MW.cs)
                if MW.realsel.isChecked() == True:
                    MW.baseline = STFT.line_baseline(MW.zerofull, MW.xzero, 5)
                    MW.zerofull = MW.zerofull - MW.baseline
                MW.ynorm = MW.zerofull / max(MW.zerofull)
                MW.fig.clf()
                MW.ax = MW.fig.add_subplot(111)
                MW.ax.plot(MW.xzero,MW.zerofull)
                for j in range(len(MW.cs)):
                   label = str(MW.cs[j])
                   MW.ax.plot(MW.xzero,MW.cszero[j],label=label)
                MW.ax.legend()
                MW.cavas.draw()

            except AttributeError:
                print(' ')
            
            try:
                print ('starting integration')
                MW.xlist, MW.ylist, MW.xref, MW.yref, MW.sumlist = STFT.integrate(MW.ynorm, MW.zerofull,
                                                                                  MW.xzero, MW.deltaY,
                                                                                  MW.minimumY, MW.minimumX, MW.maximumX)
                max_value = max(MW.zerofull)
                for i in range(0, len(MW.sumlist)):
                    MW.sumlist[i] = max_value * MW.sumlist[i]
                MW.xcent = []
                MW.height = []
                for i in range(0, len(MW.xlist)):
                    sumnum = 0
                    for j in range(len(MW.xref[i])):
                        sumnum += MW.xref[i][j] * MW.yref[i][j]
                    MW.height.append(MW.yref[i][int(len(MW.yref[i])/2)])
                    MW.xcent.append(sumnum / sum(MW.yref[i]))
                for i in range(0, len(MW.xref)):
                    MW.ax.fill_between(MW.xref[i], MW.yref[i])
                    

            except AttributeError:
                print(' ')
            self.save_FT()              

            """
            try:
                print ('starting integration')
                
                MW.yref, MW.sumlist, MW.xlist = STFT.batchintegrate(MW.ynorm, MW.zerofull, MW.xzero, MW.xref)
                
                max_value = max(MW.zerofull)
                for i in range(0, len(MW.sumlist)):
                    MW.sumlist[i] = max_value * MW.sumlist[i]
                print (MW.sumlist)
                    
                
                MW.xcent = []
                sumnum = 0
                for i in range(0, len(MW.xref)):
                    for j in range(0,len(MW.xcat)):
                        sumnum += MW.xcat[j] * MW.yref[j]
                        MW.xcent.append(sumnum / sum(MW.yref[i]))
                print (MW.xcent)
                for i in range(0, len(MW.xref)):
                    MW.ax.fill_between(MW.xref[i], MW.yref[i])
                

            except AttributeError:
                print(' ')
            self.save_FT()
            """
    #### extra windows ######
    def harmonic(self):
        self.dialog = hamu(self)
        self.dialog.show()

    def inte(self):
        self.dialog = integrate(self)
        self.dialog.show()

    def STFT_iFAMS(self):
        self.dialog = iFAMS_STFT(self)
        self.dialog.show()

    def STFT_parm_window(self):
        self.dialog = STFT_parm(self)
        self.dialog.show()

    def maxima_finder(self):
        self.dialog = Maxi(self)
        self.dialog.show()

    def man_input(self):
        self.dialog = manu(self)
        self.dialog.show()
        
    def cali(self):
        self.dialog = Calibration(self)
        self.dialog.show()
    
    def cali2(self):
        self.dialog = Calibration2(self)
        self.dialog.show()
        
    def harm_finder(self):
        self.dialog = HarmonicFinder(self)
        self.dialog.show()
        
    """  
    def noisemenu(self):
        self.dialog = Noise(self)
        self.dialog.show()        
    """
#### extra windows ######
        
def my_excepthook(type, value, tback):
    sys.__excepthook__(type, value, tback)

sys.excepthook = my_excepthook

def main():
    app = QtWidgets.QApplication(sys.argv) #create iFAMS application
    form = MW()
    form.show() #show GUI on the screen
    app.exec_() #now execute the application, do what I said above

if __name__ == "__main__":
    main()
"""
find whats called main and run it
"""

