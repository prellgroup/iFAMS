import numpy as np
from PyQt5 import QtWidgets, QtGui, QtCore
import os
import matplotlib.pyplot as plt

def load_file_norm(self):
    """
    Initiates the load dialog, and names two objects, x and y,
    which are arrays that hold m/z (x) and abundance(y) values.
    A third object, "namebase" is file naming purposes in later
    save def's
    :param self:
    :return: x,y,namebase
    """
    name = QtWidgets.QFileDialog.getOpenFileName(self,'Open File')
    namestr = str(name[0])
    namebase = os.path.splitext(namestr)[0]
    try:
        if namestr.endswith('.csv'):
            x, y = np.loadtxt(namestr,unpack=True,delimiter=',')
            for i in range(0, len(x)):
                x[i] = round(x[i],7)
                y[i] = round(y[i],7)
        elif namestr.endswith('.txt'):
            x, y = np.loadtxt(namestr,unpack=True)
            for i in range(0, len(x)):
                x[i] = round(x[i],7)
                y[i] = round(y[i],7)
        return x, y,namebase

    except UnboundLocalError:
        print('an exception was found')

def datapro(x,y):
    """
    A simple function that prepares the x and y for Fourier transform
    1. interpolates that data
    2. zero pads the data
    :param x: m/z values
    :param y: abundance values
    :return: xint,yint,ypadd
    """
    xint = np.linspace(min(x),max(x),len(x))
    yint = np.interp(xint,x,y)
    for i in range(len(yint)):
        po2 = 2**i
        if po2 >len(y):
            break
    zeros = np.zeros(po2-len(y))
    ypadd = np.append(yint,zeros)
    spacing = (xint[1]-xint[0])
    xend = po2-len(xint)
    xpadd = np.linspace(xint[0],xint[-1]+spacing*xend,po2)
    return xint,yint,ypadd,po2,xpadd

def batch_load(name):
    namestr = str(name)
    namebase = os.path.splitext(namestr)[0]

    if namestr.endswith('.csv'):
        x, y = np.loadtxt(namestr,unpack=True,delimiter=',')
        for i in range(0, len(x)):
            x[i] = round(x[i],7)
            y[i] = round(y[i],7)
    elif namestr.endswith('.txt'):
        x, y = np.loadtxt(namestr,unpack=True)
        for i in range(0, len(x)):
            x[i] = round(x[i],7)
            y[i] = round(y[i],7)

    return x,y,namebase,namestr

def rec(rlist,cs):
    rectangles = []
    for i in range(0,len(cs)):
        rectemp = []
        for j in range(len(rlist)):
            if rlist[j][4] == i:
                rectemp.append(rlist[j])
            else:
                continue
        rectangles.append(rectemp)
    return rectangles
